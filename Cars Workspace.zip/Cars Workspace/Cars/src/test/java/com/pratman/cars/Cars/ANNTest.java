package com.pratman.cars.Cars;

import java.text.DecimalFormat;

import com.pratman.cars.ANN;

public class ANNTest {

	public static void main(String[] args) {
		
		DecimalFormat df = new DecimalFormat("+ 0.00000;- 0.00000");
		
		int positive = 0;
		
		for (int j = 0; j < 1000; j++) {
			int[] layers = {8, 60, 100, 30, 1};
			ANN ann = new ANN(layers);
			
			double[] weights = new double[ann.getWeightsCount()];
			for (int i = 0; i < weights.length; i++) {
				weights[i] = (Math.random() - 0.5) / 10;
			}
			ann.setWeights(weights);
			
			double[] inputs = new double[8];
			for (int i = 0; i < inputs.length; i++) {
				inputs[i] = Math.random() / 100;
			}
			
			double result = ann.evaluate(inputs) - 0.5;
			
			if (result > 0) positive++;
			
			System.out.println(df.format(result));
		}
		
		System.out.println("\nPositive: " + positive + "\nNegative: " + (1000 - positive));
	}
	
}

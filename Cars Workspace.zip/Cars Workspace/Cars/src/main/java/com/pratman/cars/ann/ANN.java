package com.pratman.cars.ann;

public class ANN {
	
	private int inputs;
	
	public ANN() {
		
	}

}

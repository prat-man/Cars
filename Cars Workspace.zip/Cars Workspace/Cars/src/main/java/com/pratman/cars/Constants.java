package com.pratman.cars;

public class Constants {
	
}

package com.pratman.cars;

public class ANN {
	
	private final int layers;
	private final int[] neurons;
	private double[] weights;
	
	public ANN(int[] neurons) {
		this.neurons = neurons;
		this.layers = neurons.length;
	}
	
	public double[] getWeights() {
		return weights;
	}
	
	public void setWeights(double[] weights) {
		this.weights = weights;
	}

	public double evaluate(double[] input) {
		// if weights are not initialized, initialize them
		if (this.weights == null) {
			this.weights = new double[this.getWeightsCount()];
			for (int i = 0; i < weights.length; i++) {
				weights[i] = Math.random() - 0.5;
			}
		}
		
		double[] lastResults = input;
		double[] results;
		int index = 0;
		
		for (int i = 1; i < this.layers; i++) {
			results = new double[this.neurons[i]];
			for (int j = 0; j < this.neurons[i]; j++) {
				for (int k = 0; k < this.neurons[i-1]; k++) {
					results[j] += lastResults[k] * weights[index + k * this.neurons[i] + j];
				}
				// use sigmoid activation function (range: 0 to 1)
				results[j] = 1.0 / (1 + Math.exp(-results[j]));
			}
			index += this.neurons[i] * this.neurons[i-1];
			lastResults = results;
		}
		
		return lastResults[0];
	}
	
	public int getWeightsCount() {
		int count = 0;
		for (int i = 0; i < layers-1; i++) {
			count += this.neurons[i] * this.neurons[i+1];
		}
		return count;
	}

}

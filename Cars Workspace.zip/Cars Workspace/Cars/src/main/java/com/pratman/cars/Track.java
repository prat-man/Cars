package com.pratman.cars;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.Link;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class Track extends SimulationBody {
	
	private Vector2 start;
	private Goal finish;

	public Track(File file) throws FileNotFoundException {
		// get file input stream and call this()
		this(new FileInputStream(file));
	}
		
	public Track(InputStream in) {
		
		try (
			InputStreamReader inr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(inr);
		) {
			List<Vector2> vertices = new ArrayList<>();
			String line;
			
			// read starting point
			if ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line);
				double xpos = Double.parseDouble(st.nextToken());
				double ypos = Double.parseDouble(st.nextToken());
				this.start = new Vector2(xpos, ypos);
			}
			
			// read finish line
			if ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line);
				
				double xpos1 = Double.parseDouble(st.nextToken());
				double ypos1 = Double.parseDouble(st.nextToken());
				Vector2 point1 = new Vector2(xpos1, ypos1);
				
				double xpos2 = Double.parseDouble(st.nextToken());
				double ypos2 = Double.parseDouble(st.nextToken());
				Vector2 point2 = new Vector2(xpos2, ypos2);
				
				this.finish = new Goal(point1, point2);
			}
			
			// mandatory line break
			br.readLine();
			
			// read track
			while ((line = br.readLine()) != null) {
				if (line.trim().equals(new String())) {
					this.addVertices(vertices);
					vertices.clear();
				}
				else {
					StringTokenizer st = new StringTokenizer(line);
					double xpos = Double.parseDouble(st.nextToken());
					double ypos = Double.parseDouble(st.nextToken());
					vertices.add(new Vector2(xpos, ypos));
				}
			}
			
			this.addVertices(vertices);
			vertices.clear();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		this.setMass(MassType.INFINITE);
		this.setColor(Color.DARK_GRAY);
	}
	
	private void addVertices(List<Vector2> vertices) {
		if (!vertices.isEmpty()) {
			List<Link> links = Geometry.createLinks(vertices, false);
			for (Link link : links) {
				this.addFixture(link);
			}
		}
	}
	
	public Vector2 getStart() {
		return start;
	}

	public Goal getFinish() {
		return finish;
	}
	
	class Goal extends SimulationBody {
		
		public Goal(Vector2 point1, Vector2 point2) {
			
			Vector2[] vertices = new Vector2[] {point1, point2};
			
			List<Link> links = Geometry.createLinks(vertices, false);

			for (Link link : links) {
				this.addFixture(link);
			}
			
			this.setMass(MassType.INFINITE);
			this.setColor(Color.GREEN);
			
		}
		
		@Override
		protected void renderFixture(Graphics2D g, double scale, BodyFixture fixture, Color color) {
			Stroke stroke = g.getStroke();
			Stroke dashed = new BasicStroke(4, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{1}, 0);
			g.setStroke(dashed);
			super.renderFixture(g, scale, fixture, color);
			g.setStroke(stroke);
		}
		
	}
	
}

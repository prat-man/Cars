package com.pratman.cars;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.CollisionAdapter;
import org.dyn4j.dynamics.RaycastResult;
import org.dyn4j.dynamics.World;
import org.dyn4j.dynamics.contact.ContactConstraint;
import org.dyn4j.geometry.Ray;

import com.pratman.cars.framework.SimulationFrame;

public final class Simulation extends SimulationFrame {
	/** The serial version id */
	private static final long serialVersionUID = -8518496343422955267L;

	/**
	 * Default constructor.
	 */
	public Simulation() {
		super("Simulation", 300.0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#initializeWorld()
	 */
	@Override
	protected void initializeWorld() {
		// no gravity on a top-down view of a race track
		this.world.setGravity(World.ZERO_GRAVITY);
		
		// the track
		String trackFileName = "track2.track";
		InputStream trackInputStream = getClass().getClassLoader().getResourceAsStream(trackFileName);
		Track track = new Track(trackInputStream);
		this.world.addBody(track);
		this.world.addBody(track.getFinish());
		
		// the cars
		List<Car> cars = new ArrayList<>();
		
		for (int i = 0; i < 10; i++) {
			Car car = new Car(track.getStart());
			cars.add(car);
			this.world.addBody(car);
		}

		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

		/*ScheduledFuture<?> schedulerHandle = */
		scheduler.scheduleAtFixedRate(() -> {
			double[] angles = { 0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75 };

			DecimalFormat df = new DecimalFormat("0.00000");
			
			boolean flag = false;
			
			for (Car car : cars) {
				if (car.isAlive()) {
					flag = true;
					
					car.adjustRotation();
		
					for (double angle : angles) {
						Ray ray = new Ray(car.getWorldCenter(), (car.getRotation() + angle) * Math.PI);
						List<RaycastResult> results = new ArrayList<>();
						world.raycast(ray, 0, true, false, results);
						if (!results.isEmpty()) {
							double distance = results.get(0).getRaycast().getDistance();
							System.out.print(df.format(distance) + " ");
						}
						else {
							System.out.print("-.----- ");
						}
					}
		
					System.out.println(" : " + car.getIterations());
				}
			}
			
			if (flag) {
				System.out.println();
			}
			else {
				for (Car car : cars) {
					this.world.removeBody(car);
				}
			}
			
		}, 0, 100, TimeUnit.MILLISECONDS);

		world.addListener(new CollisionAdapter() {
			@Override
			public boolean collision(ContactConstraint contactConstraint) {
				Body body1 = contactConstraint.getBody1();
				Body body2 = contactConstraint.getBody2();
				
				if (body1 instanceof Car && body2 instanceof Car) {
					// Do nothing - two cars cannot collide
					return false;
				}
				else {
					if (body1 instanceof Car) {
						((Car) body1).setAlive(false);
					}
					else if (body2 instanceof Car) {
						((Car) body2).setAlive(false);
					}
					return super.collision(contactConstraint);
				}
			}
		});
	}

	/**
	 * Entry point for the example application.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		Simulation simulation = new Simulation();
		simulation.run();
	}
}

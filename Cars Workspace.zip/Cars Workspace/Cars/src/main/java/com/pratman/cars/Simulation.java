package com.pratman.cars;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.CollisionAdapter;
import org.dyn4j.dynamics.RaycastResult;
import org.dyn4j.dynamics.World;
import org.dyn4j.dynamics.contact.ContactConstraint;
import org.dyn4j.geometry.Ray;

import com.pratman.cars.framework.SimulationFrame;

public final class Simulation extends SimulationFrame {
	/** The serial version id */
	private static final long serialVersionUID = -8518496343422955267L;
	
	private List<Car> cars;
	private String trackFileName;
	private int generation;

	/**
	 * Default constructor.
	 */
	public Simulation() {
		super("Simulation", 300.0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#initializeWorld()
	 */
	@Override
	protected void initializeWorld() {
		this.generation = 0;
		cars = new ArrayList<>();
		trackFileName = "track2.track";
		
		// no gravity on a top-down view of a race track
		this.world.setGravity(World.ZERO_GRAVITY);
		
		// the track
		InputStream trackInputStream = getClass().getClassLoader().getResourceAsStream(trackFileName);
		Track track = new Track(trackInputStream);
		this.world.addBody(track);
		this.world.addBody(track.getFinish());
		
		// the cars
		for (int i = 0; i < 100; i++) {
			Car car = new Car(track.getStart());
			cars.add(car);
			this.world.addBody(car);
		}

		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

		/*ScheduledFuture<?> schedulerHandle = */
		scheduler.scheduleAtFixedRate(() -> {
			
			//double rand = Math.random();
			
			double[] angles = { 0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75 };
			
			boolean flag = false;
			
			for (Car car : cars) {
				if (car.isAlive()) {
					flag = true;
					
					int index = 0;
					double[] sensors = new double[8];
		
					for (double angle : angles) {
						Ray ray = new Ray(car.getWorldCenter(), (car.getRotation() + angle) * Math.PI);
						List<RaycastResult> results = new ArrayList<>();
						
						//System.out.println("IN : " + rand);
						
						world.raycast(ray, 0, true, true, results);
						
						//System.out.println("OUT: " + rand + "\n");
						
						if (!results.isEmpty()) {
							int k = 0;
							while (k < results.size() && results.get(k).getBody() instanceof Car) {
								k++;
							}
							
							if (k < results.size()) {
								sensors[index] = results.get(k).getRaycast().getDistance();
							}
							index++;
						}
						
						//System.out.print(sensors[index - 1] + " ");
					}
					
					//System.out.println();
					
					car.adjustRotation(sensors);
					
					// timeout after 50 iteration
					if (car.getIterations() > 50) {
						car.setTimeout(true);
					}
				}
			}
			
			if (!flag) {
				/*
				for (Car car : cars) {
					this.world.removeBody(car);
				}
				*/
				this.world.removeAllBodies();
				
				this.world.addBody(track);
				this.world.addBody(track.getFinish());
				
				// do an ascending sort, such that car with greatest fitness is at last
				Collections.sort(cars);
				
				List<Car> offsprings = new ArrayList<>();
				
				for (int i = 0; i < cars.size(); i++) {
					int index1, index2;
					
					{
						// get a random number
						int chance = (int) (Math.random() * (cars.size() * cars.size()));
						
						// generate a weighted random index
						int j = 0, index = 0;
						while (j < chance) {
							j += index;
							index = ++index % cars.size();
						}
						
						index1 = index;
					}
					
					{
						// get a random number
						int chance = (int) (Math.random() * (cars.size() * cars.size()));
						
						// generate a weighted random index
						int j = 0, index = 0;
						while (j < chance) {
							j += index;
							index = ++index % cars.size();
						}
						
						index2 = index;
					}
					
					Car offspring = cars.get(index1).crossoverAndMutate(cars.get(index2));
					
					offsprings.add(offspring);
					
					offspring.setStart(track.getStart());
				}
				
				cars = offsprings;
				
				for (Car car : cars) {
					this.world.addBody(car);
				}
				
				this.generation++;
				System.out.println(this.generation);
			}
			
		}, 0, 100, TimeUnit.MILLISECONDS);

		world.addListener(new CollisionAdapter() {
			@Override
			public boolean collision(ContactConstraint contactConstraint) {
				Body body1 = contactConstraint.getBody1();
				Body body2 = contactConstraint.getBody2();
				
				if (body1 instanceof Car && body2 instanceof Car) {
					// Do nothing - two cars cannot collide
					return false;
				}
				else {
					if (body1 instanceof Car) {
						Car car = (Car) body1;
						car.setAlive(false);
						if (body2 == track.getFinish()) {
							// car has reached goal
							car.setCompleted(true);
							world.removeBody(car);
							System.out.println(car);
						}
					}
					else if (body2 instanceof Car) {
						Car car = (Car) body2;
						car.setAlive(false);
						if (body1 == track.getFinish()) {
							// car has reached goal
							car.setCompleted(true);
							world.removeBody(car);
							System.out.println(car);
						}
					}
					return super.collision(contactConstraint);
				}
			}
		});
	}

	/**
	 * Entry point for the example application.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		Simulation simulation = new Simulation();
		simulation.run();
	}
}

package com.pratman.cars;

import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class Car extends SimulationBody implements Comparable<Car> {
	
	public static final double WIDTH = 0.05;
	public static final double HEIGHT = 0.07;
	public static final double VELOCITY = 1.0;
	
	private double rotation;
	private boolean alive;
	private int iterations;
	private boolean completed;
	private boolean timeout;
	
	private ANN ann;
	
	public Car() {
		this(new Vector2());
	}
	
	public Car(Vector2 start) {
		this.rotation = 0;
		this.alive = true;
		this.iterations = 0;
		// initialize object
		this.addFixture(Geometry.createRectangle(WIDTH, HEIGHT));
		this.translate(start);
		this.setMass(MassType.NORMAL);
		this.rotateAboutCenter(0);
		// initialize ANN
		this.ann = new ANN(new int[]{8, 60, 100, 30, 1});
	}
	
	@Override
	public void rotateAboutCenter(double theta) {
		this.rotation += theta;
		double x = VELOCITY * Math.cos(rotation + 0.5 * Math.PI);
		double y = VELOCITY * Math.sin(rotation + 0.5 * Math.PI);
		this.setLinearVelocity(x, y);
		super.rotateAboutCenter(theta);
	}
	
	public void setStart(Vector2 start) {
		this.translate(start);
	}

	public double getRotation() {
		return rotation;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
		if (!this.alive) {
			this.setLinearVelocity(0, 0);
		}
	}
	
	public int getIterations() {
		return iterations;
	}
	
	public boolean hasCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	
	public boolean hasTimeout() {
		return timeout;
	}

	public void setTimeout(boolean timeout) {
		this.timeout = timeout;
		this.setAlive(!timeout);
	}

	public ANN getANN() {
		return ann;
	}

	public void adjustRotation(double[] input) {
		double rotation = ann.evaluate(input) - 0.5;
		this.rotateAboutCenter(rotation * Math.PI);
		this.iterations++;
	}
	
	public Car crossoverAndMutate(Car other) {
		// create offspring car instance
		Car car = new Car();
		
		// crossover of weights
		double[] weights = new double[car.getANN().getWeightsCount()];
		double[] thisWeights = this.getANN().getWeights();
		double[] otherWeights = this.getANN().getWeights();
		for (int i = 0; i < weights.length; i++) {
			// using coin toss to select parent chromosome
			if ((int)(Math.random() * 10) % 2 == 0) {
				weights[i] = thisWeights[i];
			}
			else {
				weights[i] = otherWeights[i];
			}
		}
		
		// crossover of biases
		double[] biases = new double[car.getANN().getBiasesCount()];
		double[] thisBiases = this.getANN().getBiases();
		double[] otherBiases = this.getANN().getBiases();
		for (int i = 0; i < biases.length; i++) {
			// using coin toss to select parent chromosome
			if ((int)(Math.random() * 10) % 2 == 0) {
				biases[i] = thisBiases[i];
			}
			else {
				biases[i] = otherBiases[i];
			}
		}
		
		// mutate weights
		if (Math.random() < Constants.MUTATION_RATE) {
			double nMutate = Math.max(weights.length * Constants.MUTATION_RATE * 10, 1);
			for (int i = 0; i < nMutate; i++) {
				int index = (int) (Math.random() * (weights.length - 1));
				weights[index] = Math.random() - 0.5;
			}
		}
		
		// mutate biases
		if (Math.random() < Constants.MUTATION_RATE) {
			double nMutate = Math.max(biases.length * Constants.MUTATION_RATE * 10, 1);
			for (int i = 0; i < nMutate; i++) {
				int index = (int) (Math.random() * (biases.length - 1));
				biases[index] = Math.random() - 0.5;
			}
		}
		
		// set weights to offspring car ANN
		car.getANN().setWeights(weights);
		
		// set biases to offspring car ANN
		car.getANN().setBiases(biases);
		
		return car;
	}

	@Override
	public int compareTo(Car other) {
		if (this.hasCompleted()) {
			if (other.hasCompleted()) {
				if (this.getIterations() < other.getIterations()) {
					return +1;
				}
				else if (this.getIterations() > other.getIterations()) {
					return -1;
				}
				else {
					return 0;
				}
			}
			else {
				return +1;
			}
		}
		else if (other.hasCompleted()) {
			return -1;
		}
		else {
			if (this.hasTimeout()) {
				if (other.hasTimeout()) {
					return 0;
				}
				else {
					return -1;
				}
			}
			else if (other.hasTimeout()) {
				return +1;
			}
			else if (this.getIterations() > other.getIterations()) {
				return +1;
			}
			else if (this.getIterations() < other.getIterations()) {
				return -1;
			}
			else {
				return 0;
			}
		}
	}

}

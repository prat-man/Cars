package com.pratman.cars;

import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class Car extends SimulationBody {
	
	public static final double WIDTH = 0.05;
	public static final double HEIGHT = 0.07;
	public static final double VELOCITY = 0.5;
	
	private double rotation;
	private boolean alive;
	private int iterations;
	private boolean completed;
	
	private ANN ann;
	
	public Car() {
		this(new Vector2());
	}
	
	public Car(Vector2 start) {
		this.rotation = 0;
		this.alive = true;
		this.iterations = 0;
		// initialize object
		this.addFixture(Geometry.createRectangle(WIDTH, HEIGHT));
		this.translate(start);
		this.setMass(MassType.NORMAL);
		this.rotateAboutCenter(0);
		// initialize ANN
		this.ann = new ANN(new int[]{8, 10, 10, 1});
	}
	
	@Override
	public void rotateAboutCenter(double theta) {
		this.rotation += theta;
		double x = VELOCITY * Math.cos(rotation + 0.5 * Math.PI);
		double y = VELOCITY * Math.sin(rotation + 0.5 * Math.PI);
		this.setLinearVelocity(x, y);
		super.rotateAboutCenter(theta);
	}

	public double getRotation() {
		return rotation;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
		if (!this.alive) {
			this.setLinearVelocity(0, 0);
		}
	}
	
	public int getIterations() {
		return iterations;
	}
	
	public boolean hasCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public void adjustRotation(double[] input) {
		double rotation = ann.evaluate(input) - 0.5;
		this.rotateAboutCenter(rotation * Math.PI);
		this.iterations++;
	}

}

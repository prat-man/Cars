package com.pratman.cars;

import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class Car extends SimulationBody {
	
	public static final double WIDTH = 0.05;
	public static final double HEIGHT = 0.07;
	public static final double VELOCITY = 1.0;
	
	private double rotation;
	private boolean alive;
	private int iterations;
	
	public Car() {
		this(new Vector2());
	}
	
	public Car(Vector2 start) {
		this.rotation = 0;
		this.alive = true;
		this.iterations = 0;
		// initialize object
		this.addFixture(Geometry.createRectangle(WIDTH, HEIGHT));
		this.translate(start);
		this.setMass(MassType.NORMAL);
		this.rotateAboutCenter(0);
	}
	
	@Override
	public void rotateAboutCenter(double theta) {
		this.rotation += theta;
		double x = VELOCITY * Math.cos(rotation + 0.5 * Math.PI);
		double y = VELOCITY * Math.sin(rotation + 0.5 * Math.PI);
		this.setLinearVelocity(x, y);
		super.rotateAboutCenter(theta);
	}

	public double getRotation() {
		return rotation;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
		if (!this.alive) {
			this.setLinearVelocity(0, 0);
		}
	}
	
	public int getIterations() {
		return iterations;
	}
	
	public void adjustRotation() {
		//this.rotateAboutCenter(-0.05 * Math.PI);
		this.rotateAboutCenter((Math.random() - 0.5) * Math.PI);
		this.iterations++;
	}

}

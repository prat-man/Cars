package com.pratman.cars;

public class ANN {
	
	private final int layers;
	private final int[] neurons;
	private double[] weights;
	private double[] biases;
	
	public ANN(int[] neurons) {
		this.neurons = neurons;
		this.layers = neurons.length;
	}
	
	public double[] getWeights() {
		return weights;
	}
	
	public void setWeights(double[] weights) {
		this.weights = weights;
	}

	public double[] getBiases() {
		return biases;
	}

	public void setBiases(double[] biases) {
		this.biases = biases;
	}

	public double evaluate(double[] input) {
		// if weights are not initialized, initialize them
		if (this.weights == null) {
			this.weights = new double[this.getWeightsCount()];
			for (int i = 0; i < weights.length; i++) {
				weights[i] = -1 + Math.random() * 2;
			}
		}
		
		// if biases are not initialized, initialize them
		if (this.biases == null) {
			this.biases = new double[this.getBiasesCount()];
			for (int i = 0; i < biases.length; i++) {
				biases[i] = -1 + Math.random() * 2;
			}
		}
		
		double[] lastResults = input;
		double[] results;
		int weightIndex = 0;
		int biasIndex = 0;
		
		for (int i = 1; i < this.layers; i++) {
			results = new double[this.neurons[i]];
			for (int j = 0; j < this.neurons[i]; j++) {
				results[j] = this.biases[biasIndex + j];
				for (int k = 0; k < this.neurons[i-1]; k++) {
					results[j] += lastResults[k] * weights[weightIndex + k * this.neurons[i] + j];
				}
				// use sigmoid activation function (range: 0 to 1)
				results[j] = 1.0 / (1 + Math.exp(-results[j]));
			}
			weightIndex += this.neurons[i] * this.neurons[i-1];
			biasIndex += this.neurons[i];
			lastResults = results;
		}
		
		return lastResults[0];
	}
	
	public int getWeightsCount() {
		int count = 0;
		for (int i = 0; i < layers-1; i++) {
			count += this.neurons[i] * this.neurons[i+1];
		}
		return count;
	}
	
	public int getBiasesCount() {
		int count = 0;
		for (int i = 1; i < layers; i++) {
			count += this.neurons[i];
		}
		return count;
	}

}

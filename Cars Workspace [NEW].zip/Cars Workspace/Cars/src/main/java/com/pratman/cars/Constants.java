package com.pratman.cars;

public class Constants {
	
	public static final double MUTATION_RATE = 0.01;
	
}

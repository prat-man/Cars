package com.pratman.cars;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.dyn4j.dynamics.BodyFixture;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.Link;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class VisibleRay extends SimulationBody {
	
	private Vector2 start;
	private Vector2 end;
		
	public VisibleRay(Vector2 start, Vector2 end) {
		
		addFixture(new Link(start, end));
		
		setColor(Color.LIGHT_GRAY);
		
	}
	
	public Vector2 getStart() {
		return start;
	}

	public Vector2 getEnd() {
		return end;
	}
	
	@Override
	protected void renderFixture(Graphics2D g, double scale, BodyFixture fixture, Color color) {
		Stroke stroke = g.getStroke();
		g.setStroke(new BasicStroke(1));
		super.renderFixture(g, scale, fixture, color);
		g.setStroke(stroke);
	}
	
}

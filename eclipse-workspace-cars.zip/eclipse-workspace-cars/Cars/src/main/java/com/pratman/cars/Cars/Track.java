package com.pratman.cars.Cars;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.Link;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;

public class Track extends SimulationBody {
	
	private File file;
	private boolean closed;
	private List<Vector2> vertices;

	public Track(File file) {
		this.file = file;
		this.vertices = new ArrayList<>();
		
		try (
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
		) {
			String line = br.readLine();
			
			if (line != null) {
				if (line.equalsIgnoreCase("open")) this.closed = false;
				else if (line.equalsIgnoreCase("closed")) this.closed = true;
				else throw new InvalidTrackFormat("Track open/closed parameter is missing");
			}
			
			while ((line = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(line);
				double xpos = Double.parseDouble(st.nextToken());
				double ypos = Double.parseDouble(st.nextToken());
				this.vertices.add(new Vector2(xpos, ypos));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if (!this.vertices.isEmpty()) {
			List<Link> links = Geometry.createLinks(vertices, this.closed);
			
			for (Link link : links) {
				this.addFixture(link);
			}
		}
		
		this.setMass(MassType.INFINITE);
		this.setColor(Color.DARK_GRAY);
	}

	public File getFile() {
		return file;
	}

	public boolean isClosed() {
		return closed;
	}

	public List<Vector2> getVertices() {
		return vertices;
	}
	
}

package com.pratman.cars.Cars;

public class InvalidTrackFormat extends RuntimeException {

	private static final long serialVersionUID = 2376389744213916542L;

	public InvalidTrackFormat() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidTrackFormat(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidTrackFormat(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidTrackFormat(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidTrackFormat(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}

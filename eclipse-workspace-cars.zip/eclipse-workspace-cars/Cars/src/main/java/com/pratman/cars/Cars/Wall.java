package com.pratman.cars.Cars;

public class Wall {

	private double length;
	private double breadth;
	private double angle;
	private double xPos;
	private double yPos;
	
	/*public Wall() {
		this(0.0);
	}
	
	public Wall(double length) {
		this(length, 0.0);
	}

	public Wall(double length, double angle) {
		this(length, 0.01, angle);
	}

	public Wall(double length, double breadth, double angle) {
		this(length, breadth, angle, 0.0, 0.0);
	}*/
	
	public Wall(double length, double breadth, double angle, double xPos, double yPos) {
		this.length = length;
		this.breadth = breadth;
		this.angle = angle;
		this.xPos = xPos;
		this.yPos = yPos;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(double angle) {
		this.angle = angle;
	}

	public double getXPos() {
		return xPos;
	}

	public void setXPos(double xPos) {
		this.xPos = xPos;
	}

	public double getYPos() {
		return yPos;
	}

	public void setYPos(double yPos) {
		this.yPos = yPos;
	}
	
}

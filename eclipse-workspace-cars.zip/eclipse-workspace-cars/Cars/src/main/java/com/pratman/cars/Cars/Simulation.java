package com.pratman.cars.Cars;

import java.awt.Color;
import java.awt.Graphics2D;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.dyn4j.dynamics.CollisionAdapter;
import org.dyn4j.dynamics.RaycastResult;
import org.dyn4j.dynamics.World;
import org.dyn4j.dynamics.contact.ContactConstraint;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Ray;

import com.pratman.cars.framework.SimulationBody;
import com.pratman.cars.framework.SimulationFrame;

public final class Simulation extends SimulationFrame {
	/** The serial version id */
	private static final long serialVersionUID = -8518496343422955267L;

	/**
	 * Default constructor.
	 */
	public Simulation() {
		super("Simulation", 300.0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#initializeWorld()
	 */
	@Override
	protected void initializeWorld() {
		// no gravity on a top-down view of a billiards game
		this.world.setGravity(World.ZERO_GRAVITY);
		// this.world.setGravity(new Vector2(0, -0.3));

		// create all your bodies/joints

		/*
		 * SimulationBody wall = new SimulationBody();
		 * wall.addFixture(Geometry.createRectangle(0.02, 0.1)); wall.translate(0, 0);
		 * wall.setMass(MassType.INFINITE); world.addBody(wall);
		 * 
		 * wall = new SimulationBody(); wall.addFixture(Geometry.createRectangle(0.02,
		 * 0.1)); wall.translate(0.2, 0); wall.setMass(MassType.INFINITE);
		 * world.addBody(wall);
		 */

		Wall[] walls = new Wall[] { new Wall(0.3, 0.01, 0.0, -0.6, 0.0), new Wall(0.3, 0.01, 0.0, -0.4, 0.0),
				new Wall(0.1, 0.01, -0.5, -0.578, 0.19), new Wall(0.05, 0.01, -1.0, -0.382, 0.16),
				new Wall(0.2, 0.01, -1.0, -0.47, 0.29), new Wall(0.3, 0.01, 1.57, -0.24, 0.343),
				new Wall(0.275, 0.01, 1.57, -0.224, 0.175) };

		for (Wall wall : walls) {
			SimulationBody wallSim = new SimulationBody();
			wallSim.addFixture(Geometry.createRectangle(wall.getBreadth(), wall.getLength()));
			wallSim.rotate(wall.getAngle());
			wallSim.translate(wall.getXPos(), wall.getYPos());
			wallSim.setMass(MassType.INFINITE);
			wallSim.setColor(Color.LIGHT_GRAY);
			world.addBody(wallSim);
		}

		SimulationBody ball = new SimulationBody();
		ball.addFixture(Geometry.createCircle(0.028575), // 2.25 in diameter = 0.028575 m radius
				217.97925, // 0.126 oz/in^3 = 217.97925 kg/m^3
				0.08, 0.9);
		ball.translate(-0.3, 0.25);
		// ball1.setLinearVelocity(5.36448, 0.0); // 12 mph = 5.36448 m/s
		ball.setLinearVelocity(-1.0, 0); // so we can see the bouncing
		ball.setMass(MassType.NORMAL);
		this.world.addBody(ball);

		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

		ScheduledFuture<?> schedulerHandle = scheduler.scheduleAtFixedRate(() -> {
			double[] angles = { 0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75 };

			DecimalFormat df = new DecimalFormat("0.00000");

			for (double angle : angles) {
				Ray ray = new Ray(ball.getWorldCenter(), Math.PI * angle);
				List<RaycastResult> results = new ArrayList<>();
				world.raycast(ray, 0, true, false, results);
				if (!results.isEmpty()) {
					double distance = results.get(0).getRaycast().getDistance();
					System.out.print(df.format(distance) + " ");
				}
				else {
					System.out.print("-.----- ");
				}
			}

			System.out.println();
			
		}, 0, 100, TimeUnit.MILLISECONDS);

		/*SwingUtilities.invokeLater(() -> {
			while (true) {
				double[] angles = { 0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75 };

				DecimalFormat df = new DecimalFormat("#.#####");

				for (double angle : angles) {
					Ray ray = new Ray(ball.getWorldCenter(), Math.PI * angle);
					List<RaycastResult> results = new ArrayList<>();
					world.raycast(ray, 0, true, false, results);
					if (!results.isEmpty()) {
						double distance = results.get(0).getRaycast().getDistance();
						System.out.print(df.format(distance) + " ");
					}

					System.out.print("- ");
				}

				System.out.println();

				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});*/

		world.addListener(new CollisionAdapter() {
			@Override
			public boolean collision(ContactConstraint contactConstraint) {
				// TODO Auto-generated method stub
				contactConstraint.getBody1().setLinearVelocity(0, 0);
				contactConstraint.getBody2().setLinearVelocity(0, 0);
				schedulerHandle.cancel(false);
				return super.collision(contactConstraint);
			}
		});

		/*
		 * SimulationBody ball1 = new SimulationBody();
		 * ball1.addFixture(Geometry.createCircle(0.028575), // 2.25 in diameter =
		 * 0.028575 m radius 217.97925, // 0.126 oz/in^3 = 217.97925 kg/m^3 0.08, 0.9);
		 * ball1.translate(-1.0, 0.0); // ball1.setLinearVelocity(5.36448, 0.0); // 12
		 * mph = 5.36448 m/s ball1.setLinearVelocity(2, 0); // so we can see the
		 * bouncing ball1.setMass(MassType.NORMAL); this.world.addBody(ball1);
		 * 
		 * SimulationBody ball2 = new SimulationBody();
		 * ball2.addFixture(Geometry.createCircle(0.028575), 217.97925, 0.08, 0.9);
		 * ball2.translate(1.0, 0.0); ball2.setMass(MassType.NORMAL);
		 * this.world.addBody(ball2);
		 */
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#render(java.awt.Graphics2D, double)
	 */
	@Override
	protected void render(Graphics2D g, double elapsedTime) {
		// move the view a bit
		g.translate(-200, 0);

		super.render(g, elapsedTime);
	}

	/**
	 * Entry point for the example application.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		Simulation simulation = new Simulation();
		simulation.run();
	}
}

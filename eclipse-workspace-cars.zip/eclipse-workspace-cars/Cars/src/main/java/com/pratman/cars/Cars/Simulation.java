package com.pratman.cars.Cars;

import java.awt.Graphics2D;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.dyn4j.dynamics.Body;
import org.dyn4j.dynamics.CollisionAdapter;
import org.dyn4j.dynamics.RaycastResult;
import org.dyn4j.dynamics.World;
import org.dyn4j.dynamics.contact.ContactConstraint;
import org.dyn4j.geometry.Geometry;
import org.dyn4j.geometry.MassType;
import org.dyn4j.geometry.Ray;
import org.dyn4j.geometry.Vector2;

import com.pratman.cars.framework.SimulationBody;
import com.pratman.cars.framework.SimulationFrame;

public final class Simulation extends SimulationFrame {
	/** The serial version id */
	private static final long serialVersionUID = -8518496343422955267L;

	/**
	 * Default constructor.
	 */
	public Simulation() {
		super("Simulation", 300.0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#initializeWorld()
	 */
	@Override
	protected void initializeWorld() {
		// no gravity on a top-down view of a race track
		this.world.setGravity(World.ZERO_GRAVITY);
		
		// the track
		String trackFileName = "track1.track";
		File trackFile = new File(getClass().getClassLoader().getResource(trackFileName).getFile());
		Track track = new Track(trackFile);
		this.world.addBody(track);
		
		// the cars
		List<Car> cars = new ArrayList<>();
		
		Vector2 start = new Vector2(-0.3, 0.3);
		
		for (int i = 0; i < 10; i++) {
			Car car = new Car(new Vector2(0.13 + 0.3 * i / 5, 0.20 + 0.3 * i / 8));
			cars.add(car);
			this.world.addBody(car);
		}

		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

		ScheduledFuture<?> schedulerHandle = scheduler.scheduleAtFixedRate(() -> {
			double[] angles = { 0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75 };

			DecimalFormat df = new DecimalFormat("0.00000");
			
			boolean flag = false;
			
			for (Car car : cars) {
				if (car.isAlive()) {
					flag = true;
					
					car.adjustRotation();
		
					for (double angle : angles) {
						Ray ray = new Ray(car.getWorldCenter(), (car.getRotation() + angle) * Math.PI);
						List<RaycastResult> results = new ArrayList<>();
						world.raycast(ray, 0, true, false, results);
						if (!results.isEmpty()) {
							double distance = results.get(0).getRaycast().getDistance();
							System.out.print(df.format(distance) + " ");
						}
						else {
							System.out.print("-.----- ");
						}
					}
		
					System.out.println(" : " + car.getIterations());
				}
			}
			
			if (flag) {
				System.out.println();
			}
			
		}, 0, 100, TimeUnit.MILLISECONDS);

		world.addListener(new CollisionAdapter() {
			@Override
			public boolean collision(ContactConstraint contactConstraint) {
				Body body1 = contactConstraint.getBody1();
				Body body2 = contactConstraint.getBody2();
				
				if (body1 instanceof Car && body2 instanceof Car) {
					// Do nothing - two cars cannot collide
					return false;
				}
				else {
					if (body1 instanceof Car) {
						((Car) body1).setAlive(false);
					}
					else if (body2 instanceof Car) {
						((Car) body2).setAlive(false);
					}
					return super.collision(contactConstraint);
				}
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dyn4j.samples.SimulationFrame#render(java.awt.Graphics2D, double)
	 */
	@Override
	protected void render(Graphics2D g, double elapsedTime) {
		// move the view a bit
		g.translate(-200, 0);

		super.render(g, elapsedTime);
	}

	/**
	 * Entry point for the example application.
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		Simulation simulation = new Simulation();
		simulation.run();
	}
}

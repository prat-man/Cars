package com.pratman.cars.Cars;

public class Constants {

	public static double carLength = 0.07;
	public static double carWidth = 0.05;
	
}
